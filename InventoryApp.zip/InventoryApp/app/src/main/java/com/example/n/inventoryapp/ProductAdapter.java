package com.example.n.inventoryapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.n.inventoryapp.Data.InventoryDbHelper;

import java.util.ArrayList;

/**
 * Created by n on 3/3/2018.
 */
public class ProductAdapter extends ArrayAdapter<Product> {

    ArrayList<Product> products = new ArrayList<>();

    public ProductAdapter(Activity context, ArrayList<Product> products) {
        super(context, 0, products);
    }

    private InventoryDbHelper db = new InventoryDbHelper(getContext());

    @NonNull
    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        final Product currentProduct = getItem(position);

        Button btnSell =  listItemView.findViewById(R.id.list_sell_btn);

        TextView mProductName =  listItemView.findViewById(R.id.list_product_name);
        assert currentProduct != null;
        mProductName.setText(currentProduct.getName());

        final TextView mInStock =  listItemView.findViewById(R.id.list_product_stock);
        mInStock.setText(Integer.toString(currentProduct.getStock()));

        TextView mProductPrice =  listItemView.findViewById(R.id.list_product_price);
        mProductPrice.setText("$" + Float.toString(currentProduct.getPrice()));

        final TextView mProductSold =  listItemView.findViewById(R.id.list_product_sold);
        mProductSold.setText(Integer.toString(currentProduct.getSales()));

        btnSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int stock = Integer.parseInt(mInStock.getText().toString());
                int sold = Integer.parseInt(mProductSold.getText().toString());

                if (stock > 0) {
                    stock--;
                    Log.d("btnSell stock: ", String.valueOf(stock));
                    sold++;
                    Log.d("btnSell sales: ", String.valueOf(sold));
                    currentProduct.setSales(sold);
                    currentProduct.setStock(stock);
                    mInStock.setText(Integer.toString(stock));
                    mProductSold.setText(Integer.toString(sold));
                    db.updateProduct(currentProduct);
                }
            }
        });
        return listItemView;
    }

}